import userRouter from './user/user.route.js'
import projectRouter from './project/project.route.js'
import authRouter from './auth/auth.router.js'





export{
    userRouter,
    projectRouter,
    authRouter
}